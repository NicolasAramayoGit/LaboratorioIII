"use strict";
///<reference path="animal.ts"/>
///<reference path="enumerado.ts"/>
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var practicaMascotas;
(function (practicaMascotas) {
    var Mascota = /** @class */ (function (_super) {
        __extends(Mascota, _super);
        function Mascota(nombre, edad, patas, tipo) {
            var _this = _super.call(this, nombre, edad, patas) || this;
            _this._tipo = tipo;
            return _this;
        }
        Mascota.prototype.toJson = function () {
            return _super.prototype.toJson.call(this) + ("\"tipo\" : \"" + practicaMascotas.animales[this._tipo] + "\"}");
        };
        return Mascota;
    }(practicaMascotas.Animal));
    practicaMascotas.Mascota = Mascota;
})(practicaMascotas || (practicaMascotas = {}));
