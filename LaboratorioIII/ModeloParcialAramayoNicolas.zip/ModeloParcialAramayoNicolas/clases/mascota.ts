
///<reference path="animal.ts"/>
///<reference path="enumerado.ts"/>

namespace practicaMascotas
{
    export class Mascota extends Animal
    {
       //private _id:number;
       public _tipo:animales;

       constructor(nombre:string, edad:number, patas:number, tipo:animales)
       {
          super(nombre,edad,patas);
          this._tipo = tipo;
       }

       toJson():string
       {
           return super.toJson() + `"tipo" : "${animales[this._tipo]}"}`;
       }
    }
}

