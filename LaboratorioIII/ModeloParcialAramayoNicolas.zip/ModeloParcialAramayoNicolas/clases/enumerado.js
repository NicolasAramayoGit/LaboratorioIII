"use strict";
var practicaMascotas;
(function (practicaMascotas) {
    var animales;
    (function (animales) {
        animales[animales["perro"] = 0] = "perro";
        animales[animales["gato"] = 1] = "gato";
        animales[animales["reptil"] = 2] = "reptil";
        animales[animales["roedor"] = 3] = "roedor";
        animales[animales["ave"] = 4] = "ave";
        animales[animales["pez"] = 5] = "pez";
    })(animales = practicaMascotas.animales || (practicaMascotas.animales = {}));
})(practicaMascotas || (practicaMascotas = {}));
