namespace practicaMascotas
{
    export enum animales
    {
        perro,
        gato,
        reptil,
        roedor,
        ave,
        pez
    }
}